# تطبيق قائمة المهام (Android)

تطبيق بسيط بلغة Kotlin و Jetpack Compose: إضافة مهمة، وتحديدها كمنجزة، وحذفها.

## البناء عبر Bitrise
1. ارفع هذا المجلد إلى مستودع Git (GitHub أو GitLab أو Bitbucket).
2. أضف التطبيق في Bitrise واربطه بالمستودع.
3. شغّل workflow باسم `primary`.
4. ستجد ملف `app-debug.apk` في قسم Artifacts للبناء.
